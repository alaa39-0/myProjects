function welcome(){
	
	alert("Welcome to our Website :)");
		
	}


function submitForm() {
  return confirm("Do you want to submit the form?");
}